var mapnik = require('mapnik'); 
var fs = require('fs'); 

const proj4 = require('proj4');
const express = require('express') 
const app = express() 
const port = 1234

// register fonts and datasource plugins
mapnik.register_default_fonts();
mapnik.register_default_input_plugins();

const sourceCRS = 'EPSG:4326';
const targetCRS = 'EPSG:3857';

function conv2(lat, lon) {
  const [x, y] = proj4(sourceCRS, targetCRS, [lon, lat]);
  return { x, y };
}

app.get('/', (req, res) => {
	const minlongm = req.query.minlong
	const maxlongm = req.query.maxlong
	const minlatm = req.query.minlat
	const maxlatm = req.query.maxlat
	const projectedmin = conv2(parseFloat(minlatm),parseFloat(minlongm));
	const projectedmax = conv2(parseFloat(maxlatm),parseFloat(maxlongm));
	console.log(projectedmin);
	console.log(projectedmax);
	var map = new mapnik.Map(256, 256);
	map.load('/data/style/mapnik.xml', function(err,map) {
    if (err) throw err;
    map.zoomToBox(parseFloat(projectedmin.x),parseFloat(projectedmin.y),parseFloat(projectedmax.x),parseFloat(projectedmax.y));
    var im = new mapnik.Image(256, 256);
    map.render(im, function(err,im) {
      if (err) throw err;
      im.encode('png', function(err,buffer) {
	  if (err) throw err;
	  /*fs.writeFile('map.png',buffer, function(err) {
	      if (err) throw err;
	      console.log('saved map image to map.png');
	  });*/
		res.type('image/png');
	  res.send(buffer);
      });
    });
	});
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
